using NUnit.Framework;
using Slots.Domain;

namespace SlotsTests
{
    public class BoardTests
    {
        [TestCase(1)]
        [TestCase(38)]
        [TestCase(2)]
        public void TestBoardHeight(int height)
        {
            var board = new Board();
            board.SetBoardHeight(height);

            Assert.AreEqual(height, board.GetBoardHeight());
        }

        [TestCase(2)]
        [TestCase(8)]
        [TestCase(6)]
        public void TestBoardWidth(int width)
        {
            var board = new Board();
            board.SetBoardWidth(width);

            Assert.AreEqual(width, board.GetBoardWidth());
        }
    }
}