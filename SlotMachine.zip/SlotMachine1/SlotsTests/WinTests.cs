using NUnit.Framework;
using Slots.Domain;

namespace SlotsTests
{
    public class WinTests
    {
        [TestCase("A A A", 1, ExpectedResult = true)]
        [TestCase("A * A", 1, ExpectedResult = true)]
        [TestCase("* * A", 1, ExpectedResult = true)]
        [TestCase("* * *", 1, ExpectedResult = false)]
        [TestCase("C A A", 1, ExpectedResult = false)]
        [TestCase("A * E", 1, ExpectedResult = false)]
        [TestCase("D D E", 1, ExpectedResult = false)]
        public bool TestWin(string Line,decimal stake)
        {
          decimal result = CheckWin.checkWin(Line, stake);

            return (result > 0);     
        }


        [TestCase("A A A ", 1, (0.4+0.4+0.4))]
        [TestCase("A * A ", 1, (0.4 + 0.4))]
        [TestCase("P P * ", 1, (0.8 + 0.8))]
        [TestCase("* B * ", 2, (0.6)*2)]
        [TestCase("P P P P ", 1, (0.8 + 0.8 + 0.8 + 0.8))]
        [TestCase("P A P P ", 1, (0))]
        public void TestWinAmt(string Line, decimal stake, decimal amount)
        {
            decimal result = CheckWin.checkWin(Line, stake);
        
             Assert.AreEqual(result,amount);
        }
        
    }

    
}