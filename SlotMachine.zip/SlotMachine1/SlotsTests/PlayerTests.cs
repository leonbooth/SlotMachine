using NUnit.Framework;
using Slots.Domain;

namespace SlotsTests
{
    public class PlayerTests
    {
        [TestCase(1, ExpectedResult = true)]
        [TestCase(3, ExpectedResult = false)]
        [TestCase(2, ExpectedResult = true)]
        public bool TestCanStake(int stake)
        {
            var player = new Player();
            player.SetBalance(2m);

            return player.CanStake(stake);
        }

        [TestCase(1, 3, 4)]
        [TestCase(2, 3, 5)]
        [TestCase(2, 6, 8)]
        public void TestUpdateBalance(decimal balance, decimal change, decimal result)
        {
            var player = new Player();
            player.SetBalance(balance);

            player.UpdateBalance(change);

            Assert.AreEqual(result, player.GetBalance());



        }
    }
}