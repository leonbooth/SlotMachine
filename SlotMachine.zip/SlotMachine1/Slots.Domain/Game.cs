﻿using Slots.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slots.Domain
{
    public class Game : IGame
    {
        private readonly ISlotsUI ui;
        private readonly IPlayer player;
        private readonly IBoard board;
        
        public Game(ISlotsUI ui,IPlayer player,IBoard board)
        {
            this.ui = ui;
            this.player = player;
            this.board = board;
        }
        public void Run()
        {
            //Decimal winAmt;
            decimal spinWinAmt;

            board.SetBoardWidth(ReadConfig.getBoardWidth());
            board.SetBoardHeight(ReadConfig.getBoardHeight());

            InitialDeposit();

            while (player.GetBalance() > 0)
            {
                decimal stakeAmount;
                try
                {
                    stakeAmount = GetStake();
                }
                catch (Exception e)
                {
                    ui.Display(e.Message);
                    continue;
                }

               board.setBoard();

                CalculateTurnResult(stakeAmount,out spinWinAmt);
                
                player.UpdateBalance(spinWinAmt);
                ui.Display("Your stake of £" + stakeAmount.ToString("0.00") + " has returned £" + spinWinAmt.ToString("0.00"));
                ui.Display("Your new balance is: £" + player.GetBalance().ToString("0.00"));
                ui.Display("Press any key to continue");
                ui.ReadKey();
                ui.Clear();
            }
            ui.Display("You have no money left :-(");
        }

        private void CalculateTurnResult(decimal stake, out decimal spinWinAmt)
        {
            decimal winAmt = 0m;
            spinWinAmt = 0;
            for (int i = 0; i < board.GetBoardHeight(); i++)
            {
                var outputLine = "";
                for (int j = 0; j < board.GetBoardWidth(); j++)
                {
                    outputLine += ReadConfig.getSymbol(Convert.ToInt32(board.GetSymbol(j, i)) ) + " ";          
                }
                winAmt = CheckWin.checkWin(outputLine, stake);
                spinWinAmt += winAmt;
                if (winAmt > 0)
                {
                    ui.DisplayWin(outputLine);
                }
                else
                {
                    ui.Display(outputLine);
                }
            }

        }

        private decimal GetStake()
        {
            decimal stakeAmount;
            ui.Display("Your balance is: £" + player.GetBalance().ToString("0.00"));
            ui.Display("Enter your stake amount:");

            stakeAmount = decimal.Parse(Console.ReadLine());

            if (stakeAmount != decimal.Round(stakeAmount, 2))
            {
                throw new Exception("You must provide a currency value to 2 decimal places");
            }
            if (player.CanStake(stakeAmount))
            {
                player.Stake(stakeAmount);
            }
            else
            {
                throw new Exception("Stake amount cannot be higher than current balance");
            }

            return stakeAmount;
        }

        private void InitialDeposit()
        {
            while (player.GetBalance() == 0)
            {
                ui.Display("Please deposit money you would like to play with:");

                try
                {
                    player.SetBalance(decimal.Parse(ui.Reader()));
                }
                catch (Exception)
                {
                    ui.Display("Only valid currency values allowed!");
                    continue;

                }
            }
        }

        
    }
}
