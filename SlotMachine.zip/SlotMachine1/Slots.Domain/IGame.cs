﻿namespace Slots.Domain
{
    public interface IGame
    {
        void Run();
    }
}