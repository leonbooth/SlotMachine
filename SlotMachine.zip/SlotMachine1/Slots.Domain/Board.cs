﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slots.Domain
{
    public class Board : IBoard
    {
        int boardheight = 0;
        int boardwidth = 0;
        List<string> resList = new List<string>();
        Random rnd = new Random();
        public void setBoard()
        {
            resList.Clear();
            for (int i = 0; i < boardwidth; i++)
            {
                string lineString = "";
                for (int j = 0; j < boardheight; j++)
                {
                    lineString += Convert.ToString(rnd.Next(1, 101)) + ",";
                }
                resList.Add(lineString);
            }  
        }

        public string GetSymbol(int xParam, int yParam)
        {
            string[] boardSymbol = resList[xParam].Split(",");
            return boardSymbol[yParam];
        }

        public void SetBoardHeight(int height)
        {
            boardheight = height;
        }

        public void SetBoardWidth(int width)
        {
            boardwidth = width;
        }

        public int GetBoardWidth()
        {
            return boardwidth;
        }

        public int GetBoardHeight()
        {
            return boardheight;
        }
    }
}
