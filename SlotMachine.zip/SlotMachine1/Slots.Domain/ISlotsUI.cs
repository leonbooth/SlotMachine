﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slots.Domain
{
    public interface ISlotsUI
    {
        void Display(string message);
        void DisplayWin(string message);
        void ReadKey();
        void Clear();
        string Reader();

                
    }
}
