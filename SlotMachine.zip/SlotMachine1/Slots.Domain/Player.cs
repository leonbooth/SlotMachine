﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slots.Domain
{
    public class Player : IPlayer
    {
        decimal balance = 0;

        public void SetBalance(decimal newBalance)
        {
            try
            {
                if (decimal.Round(newBalance, 2) == newBalance)
                {
                    balance = newBalance;
                } else
                {
                    throw new Exception("Only two decimal places allowed");
                }

            } catch
            {
                throw new Exception("Unable to set balance, please enter a valid currency");
            }
            
        }

        public decimal GetBalance()
        {
            return balance;
        }

        public bool CanStake(decimal myStake)
        {
            if (myStake > balance)
            {
                return false;
            }

            return true;
        }

        public void UpdateBalance(decimal win)
        {
            balance = decimal.Round(balance + win, 2);
        }

        public void Stake(decimal stakeAmount)
        {
            balance = balance - stakeAmount;
        }
    }
}
