﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Slots.Domain
{
    class ReadConfig
    {
        private static string filename = Path.Combine(AppContext.BaseDirectory,"Config.xml") ;
        
        public static int getBoardWidth()
        {
            
            XmlDocument doc = new XmlDocument();
            doc.Load(filename);
            XmlNode width = doc.SelectSingleNode("/game/board/width");
            int boardCols = Convert.ToInt32(width.InnerText);
            return boardCols;
        }

        public static int getBoardHeight()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(filename);
            XmlNode height = doc.SelectSingleNode("/game/board/height");
            int boardRows = Convert.ToInt32(height.InnerText);
            return boardRows;
        }

        public static string getSymbol(int random)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(filename);
            XmlNodeList xmlNodeList = doc.SelectNodes("/game/symbols/symbol");
            int numSymbols = xmlNodeList.Count;
            decimal[] symbolProb = new decimal[numSymbols];
            String[] symbolDisp = new String[numSymbols];
            decimal[] symbolCoEf = new decimal[numSymbols];
            int i = 0;
            decimal totalProb = 0;
            foreach (XmlNode symbol in xmlNodeList)
            {
                symbolProb[i] = decimal.Parse(symbol.SelectSingleNode("probability").InnerText);
                symbolDisp[i] = symbol.SelectSingleNode("display").InnerText;
                symbolCoEf[i] = decimal.Parse(symbol.SelectSingleNode("coefficient").InnerText);
                totalProb += symbolProb[i];
                if ( random <= (totalProb * 100))
                {
                    return symbolDisp[i];
                }
                i++;
            }

            return "Error";
        }

        public static decimal GetWinValue(string winSymbol)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(filename);
            XmlNodeList xmlNodeList = doc.SelectNodes("/game/symbols/symbol");
            
                foreach (XmlNode symbol in xmlNodeList)
                {
                    if (symbol.SelectSingleNode("display").InnerText == winSymbol)
                    {
                        return decimal.Parse(symbol.SelectSingleNode("coefficient").InnerText);
                    }
                }
                return 0;  
        }
        
    }
}
