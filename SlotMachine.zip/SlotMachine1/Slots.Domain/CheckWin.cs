﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slots.Domain
{
    public static class CheckWin
    {
        public static decimal checkWin(string reelString, Decimal stakeAmt)
        {
            decimal winAmt = 0;
            decimal winVal;
            string temp = reelString.Trim();
            string[] arr = temp.Split(" ");
            int rowSize = arr.Length;
            int numberOfWildcards = arr.Count(item => item == "*");
            string[] arrWithoutWildcards = arr.Where(item => item != "*" && !string.IsNullOrEmpty(item)).ToArray();

            //only wildcard cannot win
            if (arrWithoutWildcards.Length <= 0)
            {
                return 0;
            }

            if (arrWithoutWildcards.All(item => item == arrWithoutWildcards[0]))
            {
                winVal = ReadConfig.GetWinValue(arrWithoutWildcards[0]);
                winAmt = stakeAmt * (winVal * arrWithoutWildcards.Length);
                
            }

            return winAmt;
        }
    }
}
