﻿namespace Slots.Domain
{
    public interface IBoard
    {
        int GetBoardHeight();
        int GetBoardWidth();
        void setBoard();
        void SetBoardHeight(int height);
        void SetBoardWidth(int width);
        string GetSymbol(int xParam, int yParam);
    }
}