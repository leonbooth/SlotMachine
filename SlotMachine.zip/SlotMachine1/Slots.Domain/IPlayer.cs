﻿namespace Slots.Domain
{
    public interface IPlayer
    {
        decimal GetBalance();
        void SetBalance(decimal newBalance);
        bool CanStake(decimal myStake);
        void UpdateBalance(decimal win);
        void Stake(decimal stakeAmount);
    }
}