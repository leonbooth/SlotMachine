using NUnit.Framework;
using Slots.Domain;

namespace TestProject1
{
    [TestFixture]
    public class PlayerTests
    {
        [TestCase(1,ExpectedResult = true)]
        [TestCase(3,ExpectedResult = false)]
        [TestCase(2,ExpectedResult = true)]
        public bool TestCanStake(int stake)
        {
            var player = new Player();
            player.SetBalance(2m);

            return player.CanStake(stake);
        }
    }
}
