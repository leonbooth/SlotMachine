﻿using Slots.Domain;
using System;

namespace Slots.UI 
{
    public class SlotsUI : ISlotsUI

    {
        public void Display(string message)
        {
            Console.WriteLine(message);
        }

        public void DisplayWin(string message)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(message);
            Console.ResetColor();
        }

        public void ReadKey()
        {
            Console.ReadKey();
        }
        public void Clear()
        {
            Console.Clear();
        }
        public string Reader()
        {
            var temp = Console.ReadLine();
            return temp;
        }
    }
}
