﻿using Microsoft.Extensions.DependencyInjection;
using Slots.Domain;
using Slots.UI;
using System;


namespace SlotMachine1
{
    class Program
    {
       
        static void Main(string[] args)
        {
            var services = new ServiceCollection()
                .AddSingleton<IPlayer, Player>()
                .AddSingleton<IGame, Game>()
                .AddSingleton<ISlotsUI, SlotsUI>()
                .AddSingleton<IBoard,Board>()
                .BuildServiceProvider();


            var game = services.GetService<IGame>();

            game.Run();

            
        }
    }
}
